<?php
class PersonalWorkOffTracker
{
    private $conn;

    public function __construct()
    {
        $this->conn = new PDO('mysql:host=localhost;dbname=work_off_tracker_for_others', 'root', '1234');
    }

    public function exportCSV()
    {
        $sql = "SELECT * FROM vaqt";
        $result = $this->conn->query($sql);

        $filename = "work_off_report_" . date('Ymd') . ".csv";
        $file = fopen('php://output', 'w');

        $header = array("ID", "Arrived At", "Leaved At", "Required Work Off", "Worked Off");
        fputcsv($file, $header);

        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($file, $row);
        }

        fclose($file);

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '";');

        exit();
    }
}
?>
