<?php
class PersonalWorkOffTracker
{
    private $conn;

    public function __construct()
    {
        $this->conn = new PDO('mysql:host=localhost;dbname=work_off_tracker_for_others', 'root', '1234');
    }

    public function addRecord($arrived_at, $leaved_at)
    {
        $arrived_at_dt = new DateTime($arrived_at);
        $leaved_at_dt = new DateTime($leaved_at);

        $interval = $arrived_at_dt->diff($leaved_at_dt);
        $hours = $interval->h + ($interval->days * 24);
        $minutes = $interval->i;

        $required_work_off = sprintf('%02d:%02d:00', $hours, $minutes);

        $sql = "INSERT INTO vaqt (arrived_at, leaved_at, required_work_off) 
                VALUES (:arrived_at, :leaved_at, :required_work_off)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':arrived_at', $arrived_at);
        $stmt->bindParam(':leaved_at', $leaved_at);
        $stmt->bindParam(':required_work_off', $required_work_off);

        $stmt->execute();
    }

    public function fetchRecords($page_id)
    {
        $offset = ($page_id - 1) * 5;
        $sql = "SELECT * FROM vaqt ORDER BY id DESC LIMIT $offset, 5";
        return $this->conn->query($sql);
    }

    public function updateWorkedOff($id)
    {
        $sql = "UPDATE vaxt SET worked_off = 1 WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    }

    public function getTotalPages($records_per_page)
    {
        $sql = "SELECT COUNT(*) as total FROM vaqt";
        $result = $this->conn->query($sql);
        $row = $result->fetch(PDO::FETCH_ASSOC);
        return ceil($row['total'] / $records_per_page);
    }
}
?>
