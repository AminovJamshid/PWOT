<?php
function renderForm()
{
    echo '
    <div class="form-container mb-4">
        <form action="" method="post" class="row g-3">
            <div class="col-md-6">
                <label for="arrived_at" class="form-label">Arrived At</label>
                <input type="datetime-local" id="arrived_at" name="arrived_at" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label for="leaved_at" class="form-label">Leaved At</label>
                <input type="datetime-local" id="leaved_at" name="leaved_at" class="form-control" required>
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>';
}

function renderTable($result)
{
    $total_hours = 0;
    $total_minutes = 0;

    if ($result->rowCount() > 0) {
        echo '<form action="" method="post">';
        echo '<table class="table table-striped">';
        echo '<thead class="table-dark"><tr><th>#</th><th>Arrived at</th><th>Leaved at</th><th>Required work off</th><th>Worked off</th></tr></thead>';
        echo '<tbody>';
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $worked_off_class = $row["worked_off"] ? 'class="worked-off"' : '';
            echo "<tr $worked_off_class>";
            echo '<td>' . $row["id"] . '</td>';
            echo '<td>' . $row["arrived_at"] . '</td>';
            echo '<td>' . $row["leaved_at"] . '</td>';
            echo '<td>' . $row["required_work_off"] . '</td>';
            echo '<td><button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#confirmModal" data-id="' . $row["id"] . '">Done</button></td>';
            echo '</tr>';

            if (!$row["worked_off"]) {
                list($hours, $minutes, $seconds) = explode(':', $row["required_work_off"]);
                $total_hours += (int)$hours;
                $total_minutes += (int)$minutes;
            }
        }
        $total_hours += floor($total_minutes / 60);
        $total_minutes = $total_minutes % 60;

        echo '<tr><td colspan="4" class="text-end fw-bold">Total work off hours</td><td>' . $total_hours . ' hours and ' . $total_minutes . ' min.</td></tr>';
        echo '</tbody>';
        echo '</table>';
        echo '<button type="submit" name="export" class="btn btn-primary">Export as CSV</button>';
        echo '</form>';
    }
}

function renderPagination($page, $total_pages)
{
    echo '
    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <li class="page-item ' . ($page <= 1 ? 'disabled' : '') . '">
                <a class="page-link" href="' . ($page > 1 ? '?page=' . ($page - 1) : '#') . '">Previous</a>
            </li>';
    for ($i = 1; $i <= $total_pages; $i++) {
        echo '<li class="page-item ' . ($page == $i ? 'active' : '') . '">
                <a class="page-link" href="?page=' . $i . '">' . $i . '</a>
            </li>';
    }
    echo '<li class="page-item ' . ($page >= $total_pages ? 'disabled' : '') . '">
                <a class="page-link" href="' . ($page < $total_pages ? '?page=' . ($page + 1) : '#') . '">Next</a>
            </li>
        </ul>
    </nav>';
}

function renderModal()
{
    echo '
    <div class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirmModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="confirmModalLabel">Confirmation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to mark this record as worked off?
                </div>
                <div class="modal-footer">
                    <form action="" method="post">
                        <input type="hidden" name="worked_off" id="workedOffId">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" name="update">Yes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>';
}
?>
